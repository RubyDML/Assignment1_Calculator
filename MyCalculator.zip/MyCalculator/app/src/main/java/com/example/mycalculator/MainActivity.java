package com.example.mycalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText resultEditText;
    private String currentInput = "";
    private ArrayList<String> calculationHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultEditText = findViewById(R.id.resultEditText);

        // Number buttons
        Button button0 = findViewById(R.id.button0);
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        Button button9 = findViewById(R.id.button9);

        // Operator buttons
        Button buttonAdd = findViewById(R.id.buttonAdd);
        Button buttonSubtract = findViewById(R.id.buttonSubtract);
        Button buttonMultiply = findViewById(R.id.buttonMultiply);
        Button buttonDivide = findViewById(R.id.buttonDivide);
        Button buttonEquals = findViewById(R.id.buttonEquals);
        Button buttonClear = findViewById(R.id.buttonClear);

        // Advanced History Button
        Button buttonHistory = findViewById(R.id.buttonHistory);

        // Set listeners for number buttons
        setNumberButtonListener(button0, "0");
        setNumberButtonListener(button1, "1");
        setNumberButtonListener(button2, "2");
        setNumberButtonListener(button3, "3");
        setNumberButtonListener(button4, "4");
        setNumberButtonListener(button5, "5");
        setNumberButtonListener(button6, "6");
        setNumberButtonListener(button7, "7");
        setNumberButtonListener(button8, "8");
        setNumberButtonListener(button9, "9");

        // Set listeners for operator buttons
        buttonAdd.setOnClickListener(v -> appendInput("+"));
        buttonSubtract.setOnClickListener(v -> appendInput("-"));
        buttonMultiply.setOnClickListener(v -> appendInput("*"));
        buttonDivide.setOnClickListener(v -> appendInput("/"));

        // Equals button to calculate the result
        buttonEquals.setOnClickListener(v -> {
            String result = calculateResult(currentInput);
            resultEditText.setText(result);
            calculationHistory.add(currentInput + " = " + result);  // Store history
            currentInput = "";  // Clear current input after calculation
        });

        // Clear button to clear the screen
        buttonClear.setOnClickListener(v -> {
            currentInput = "";
            resultEditText.setText("");
        });

        // History button to navigate to the HistoryActivity
        buttonHistory.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, History.class);
            intent.putStringArrayListExtra("history", calculationHistory);  // Pass history via intent
            startActivity(intent);
        });
    }

    // Method to append number to current input
    private void setNumberButtonListener(Button button, String number) {
        button.setOnClickListener(v -> {
            currentInput += number;
            resultEditText.setText(currentInput);
        });
    }

    // Method to append operator to current input
    private void appendInput(String operator) {
        currentInput += operator;
        resultEditText.setText(currentInput);
    }

    // Method to calculate result based on the input
    private String calculateResult(String input) {
        try {
            // You can enhance this logic to support more complex operations
            String result = String.valueOf(eval(input));
            return result;
        } catch (Exception e) {
            return "Error";
        }
    }

    // Simple eval function (you can use a more robust solution for real-world use)
    public double eval(final String str) {
        return new Object() {
            int pos = -1, c;

            void nextChar() {
                c = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (c == ' ') nextChar();
                if (c == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) c);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) x /= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();

                double x;
                int startPos = this.pos;
                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                } else if ((c >= '0' && c <= '9') || c == '.') {
                    while ((c >= '0' && c <= '9') || c == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) c);
                }
                return x;
            }
        }.parse();
    }
}